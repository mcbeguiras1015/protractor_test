export * from './edit-appointment.component';
export * from './appointment.model';
export * from './appointment.service';
export * from './appointment-resolver';
