import { InjectionToken } from '@angular/core';

export const MOMENT_TOKEN = new InjectionToken<Object>('moment');
